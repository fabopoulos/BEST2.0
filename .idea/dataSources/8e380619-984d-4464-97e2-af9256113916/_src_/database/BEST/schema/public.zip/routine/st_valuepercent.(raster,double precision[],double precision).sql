create function st_valuepercent(rast raster, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) returns SETOF record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT value, percent FROM public._ST_valuecount($1, 1, TRUE, $2, $3)
$$;
