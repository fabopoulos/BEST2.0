create function st_approxquantile(rastertable text, rastercolumn text, exclude_nodata_value boolean, quantile double precision DEFAULT NULL::double precision) returns double precision
STABLE
LANGUAGE SQL
AS $$
SELECT ( public._ST_quantile($1, $2, 1, $3, 0.1, ARRAY[$4]::double precision[])).value
$$;
