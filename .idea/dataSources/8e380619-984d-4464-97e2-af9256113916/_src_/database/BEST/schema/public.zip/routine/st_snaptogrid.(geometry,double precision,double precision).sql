create function st_snaptogrid(geometry, double precision, double precision) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_SnapToGrid($1, 0, 0, $2, $3)
$$;
