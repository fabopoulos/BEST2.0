create function st_approxsummarystats(rastertable text, rastercolumn text, nband integer, sample_percent double precision) returns summarystats
STABLE
LANGUAGE SQL
AS $$
SELECT public._ST_summarystats($1, $2, $3, TRUE, $4)
$$;
