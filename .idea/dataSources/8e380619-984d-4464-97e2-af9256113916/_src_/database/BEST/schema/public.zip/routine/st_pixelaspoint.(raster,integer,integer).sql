create function st_pixelaspoint(rast raster, x integer, y integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_PointN(ST_ExteriorRing(geom), 1) FROM public._ST_pixelaspolygons($1, NULL, $2, $3)
$$;
