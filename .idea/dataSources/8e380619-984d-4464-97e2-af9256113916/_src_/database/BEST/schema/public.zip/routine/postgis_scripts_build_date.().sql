create function postgis_scripts_build_date() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2017-07-13 13:06:35'::text AS version
$$;
