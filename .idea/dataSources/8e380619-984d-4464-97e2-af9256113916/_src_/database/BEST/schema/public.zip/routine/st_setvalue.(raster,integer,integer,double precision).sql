create function st_setvalue(rast raster, x integer, y integer, newvalue double precision) returns raster
LANGUAGE SQL
AS $$
SELECT public.ST_setvalue($1, 1, $2, $3, $4)
$$;
