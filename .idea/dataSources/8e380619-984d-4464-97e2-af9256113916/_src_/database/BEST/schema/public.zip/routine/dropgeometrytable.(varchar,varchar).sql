create function dropgeometrytable(schema_name character varying, table_name character varying) returns text
LANGUAGE SQL
AS $$
SELECT DropGeometryTable('',$1,$2)
$$;
