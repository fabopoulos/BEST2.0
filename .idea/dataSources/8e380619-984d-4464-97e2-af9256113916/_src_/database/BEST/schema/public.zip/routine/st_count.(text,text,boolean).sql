create function st_count(rastertable text, rastercolumn text, exclude_nodata_value boolean) returns bigint
STABLE
LANGUAGE SQL
AS $$
SELECT public._ST_count($1, $2, 1, $3, 1)
$$;
