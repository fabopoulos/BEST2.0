create function st_bandisnodata(rast raster, forcechecking boolean) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_bandisnodata($1, 1, $2)
$$;
