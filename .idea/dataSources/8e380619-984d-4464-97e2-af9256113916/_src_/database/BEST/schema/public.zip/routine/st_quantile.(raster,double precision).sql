create function st_quantile(rast raster, quantile double precision) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ( public._ST_quantile($1, 1, TRUE, 1, ARRAY[$2]::double precision[])).value
$$;
