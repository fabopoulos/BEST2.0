create function st_approxquantile(rast raster, quantiles double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_quantile($1, 1, TRUE, 0.1, $2)
$$;
