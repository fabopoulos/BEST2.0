create function postgis_scripts_installed() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.3.3'::text || ' r' || 15473::text AS version
$$;
