create function st_area(text) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_Area($1::public.geometry);
$$;
